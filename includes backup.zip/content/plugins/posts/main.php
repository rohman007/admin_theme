<?php

$plugin = get_plugin_info('posts');

require_once($plugin['path'].'/Post.php');

?>
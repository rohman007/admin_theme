// This scipt file is not used
// Replaced with main.js
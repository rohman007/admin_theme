<?php

define("GAME_REPORTS", true);

?>
<div class="sidebar">
	<?php widget_aside('sidebar-1') ?>
</div>
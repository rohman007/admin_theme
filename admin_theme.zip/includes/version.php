<?php

define( "VERSION", "1.5.6" );

?>